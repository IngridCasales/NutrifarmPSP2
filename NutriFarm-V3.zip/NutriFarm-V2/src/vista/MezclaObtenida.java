package vista;

import java.awt.CardLayout;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SpringLayout;

import modelo.Mezcla;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MezclaObtenida extends JPanel {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panelTabla;
	private CardLayout tarjetero;
	private JComboBox <String> comboBox;
	private Mezcla concentrado;
	private JTable table;
	
	public MezclaObtenida(Mezcla concentrado,CardLayout tarjetero, JPanel contenedor) {
		this.concentrado = concentrado;
		this.contentPane = contenedor;
		this.tarjetero = tarjetero;
		setBackground(new Color(255, 192, 203));
		setBounds(100, 100, 330, 500);
		SpringLayout springLayout = new SpringLayout();
		setLayout(springLayout);
		
		JLabel label = new JLabel("NUTRI");
		label.setForeground(Color.RED);
		label.setFont(new Font("Lucida Grande", Font.PLAIN, 30));
		label.setBackground(Color.RED);
		add(label);
		
		JLabel label_1 = new JLabel("Farm");
		springLayout.putConstraint(SpringLayout.NORTH, label_1, 26, SpringLayout.NORTH, this);
		springLayout.putConstraint(SpringLayout.WEST, label_1, 167, SpringLayout.WEST, this);
		springLayout.putConstraint(SpringLayout.NORTH, label, 0, SpringLayout.NORTH, label_1);
		springLayout.putConstraint(SpringLayout.EAST, label, -6, SpringLayout.WEST, label_1);
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Lucida Grande", Font.BOLD, 30));
		add(label_1);
		
		JLabel lblEspecie = new JLabel("Especie:");
		springLayout.putConstraint(SpringLayout.WEST, lblEspecie, 42, SpringLayout.WEST, this);
		lblEspecie.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		add(lblEspecie);
		
		JLabel especie = new JLabel(concentrado.getAnimal().getEspecie());
		springLayout.putConstraint(SpringLayout.NORTH, especie, 0, SpringLayout.NORTH, lblEspecie);
		springLayout.putConstraint(SpringLayout.WEST, especie, 0, SpringLayout.WEST, label_1);
		especie.setForeground(new Color(255, 255, 255));
		especie.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		add(especie);
		
		JLabel lblMezclaObtenida = new JLabel("Mezcla obtenida");
		springLayout.putConstraint(SpringLayout.NORTH, lblEspecie, 18, SpringLayout.SOUTH, lblMezclaObtenida);
		springLayout.putConstraint(SpringLayout.NORTH, lblMezclaObtenida, 6, SpringLayout.SOUTH, label);
		springLayout.putConstraint(SpringLayout.WEST, lblMezclaObtenida, 10, SpringLayout.WEST, label);
		lblMezclaObtenida.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		add(lblMezclaObtenida);
		
		JLabel lblEtapa = new JLabel("Etapa:");
		springLayout.putConstraint(SpringLayout.NORTH, lblEtapa, 6, SpringLayout.SOUTH, lblEspecie);
		springLayout.putConstraint(SpringLayout.WEST, lblEtapa, 0, SpringLayout.WEST, lblEspecie);
		lblEtapa.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		add(lblEtapa);
		
		JLabel etapa = new JLabel(concentrado.getAnimal().getEtapa());
		springLayout.putConstraint(SpringLayout.NORTH, etapa, 6, SpringLayout.SOUTH, especie);
		springLayout.putConstraint(SpringLayout.WEST, etapa, 0, SpringLayout.WEST, label_1);
		etapa.setForeground(new Color(255, 255, 255));
		etapa.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		add(etapa);
		
		JLabel lblPeso = new JLabel("Peso:");
		springLayout.putConstraint(SpringLayout.NORTH, lblPeso, 6, SpringLayout.SOUTH, lblEtapa);
		springLayout.putConstraint(SpringLayout.WEST, lblPeso, 0, SpringLayout.WEST, lblEspecie);
		springLayout.putConstraint(SpringLayout.SOUTH, lblPeso, -324, SpringLayout.SOUTH, this);
		lblPeso.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		add(lblPeso);
		
		JLabel lblPes = new JLabel(""+concentrado.getAnimal().getRangoDePeso());
		springLayout.putConstraint(SpringLayout.NORTH, lblPes, 0, SpringLayout.NORTH, lblPeso);
		springLayout.putConstraint(SpringLayout.EAST, lblPes, 0, SpringLayout.EAST, especie);
		lblPes.setForeground(new Color(255, 255, 255));
		lblPes.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		add(lblPes);
		
		JLabel lblGanancia = new JLabel("Ganancia:");
		springLayout.putConstraint(SpringLayout.NORTH, lblGanancia, 6, SpringLayout.SOUTH, lblPeso);
		springLayout.putConstraint(SpringLayout.WEST, lblGanancia, 0, SpringLayout.WEST, lblEspecie);
		lblGanancia.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		add(lblGanancia);
		
		JLabel lblGana = new JLabel(""+concentrado.getAnimal().getGanancia());
		springLayout.putConstraint(SpringLayout.NORTH, lblGana, 0, SpringLayout.NORTH, lblGanancia);
		springLayout.putConstraint(SpringLayout.WEST, lblGana, 0, SpringLayout.WEST, label_1);
		springLayout.putConstraint(SpringLayout.EAST, lblGana, -153, SpringLayout.EAST, this);
		lblGana.setForeground(new Color(255, 255, 255));
		lblGana.setFont(new Font("Lucida Grande", Font.BOLD, 15));
		add(lblGana);
		
		JButton btnExpotar = new JButton("Expotar");
		springLayout.putConstraint(SpringLayout.WEST, btnExpotar, 28, SpringLayout.WEST, this);
		btnExpotar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				exporta();
			}
		});
		springLayout.putConstraint(SpringLayout.SOUTH, btnExpotar, -22, SpringLayout.SOUTH, this);
		add(btnExpotar);
		
		comboBox = new JComboBox <String>();
		springLayout.putConstraint(SpringLayout.WEST, comboBox, 28, SpringLayout.WEST, this);
		springLayout.putConstraint(SpringLayout.SOUTH, comboBox, -18, SpringLayout.NORTH, btnExpotar);
		add(comboBox);
		comboBox.addItem("-");
		comboBox.addItem("JPG");
		comboBox.addItem("PDF");
		
		JButton btnMenu = new JButton("Menu");
		springLayout.putConstraint(SpringLayout.EAST, btnMenu, -24, SpringLayout.EAST, this);
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tarjetero.show(contentPane,"menu2");
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, btnMenu, 0, SpringLayout.NORTH, btnExpotar);
		add(btnMenu);
		
		panelTabla = new JPanel();
		springLayout.putConstraint(SpringLayout.NORTH, panelTabla, 248, SpringLayout.NORTH, this);
		springLayout.putConstraint(SpringLayout.WEST, panelTabla, 28, SpringLayout.WEST, this);
		springLayout.putConstraint(SpringLayout.SOUTH, panelTabla, -33, SpringLayout.NORTH, comboBox);
		springLayout.putConstraint(SpringLayout.EAST, panelTabla, 296, SpringLayout.WEST, this);
		add(panelTabla);
		panelTabla.setLayout(new CardLayout(0, 0));
		muestraTabla();
	}
	
	public void muestraTabla() {
    panelTabla.removeAll();
    int numeroIng = concentrado.getIngredientes().size();
    if(numeroIng == 0) {
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 1) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 2) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]},
          {concentrado.getIngredientes().get(1).getNombre(),concentrado.getIngredientes().get(1).getPc(),
           concentrado.getIngredientes().get(1).getTnd(),cant[1]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 3) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]},
          {concentrado.getIngredientes().get(1).getNombre(),concentrado.getIngredientes().get(1).getPc(),
           concentrado.getIngredientes().get(1).getTnd(),cant[1]},
          {concentrado.getIngredientes().get(2).getNombre(),concentrado.getIngredientes().get(2).getPc(),
           concentrado.getIngredientes().get(2).getTnd(),cant[2]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 4) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]},
          {concentrado.getIngredientes().get(1).getNombre(),concentrado.getIngredientes().get(1).getPc(),
           concentrado.getIngredientes().get(1).getTnd(),cant[1]},
          {concentrado.getIngredientes().get(2).getNombre(),concentrado.getIngredientes().get(2).getPc(),
           concentrado.getIngredientes().get(2).getTnd(),cant[2]},
          {concentrado.getIngredientes().get(3).getNombre(),concentrado.getIngredientes().get(3).getPc(),
           concentrado.getIngredientes().get(3).getTnd(),cant[3]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 5) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]},
          {concentrado.getIngredientes().get(1).getNombre(),concentrado.getIngredientes().get(1).getPc(),
           concentrado.getIngredientes().get(1).getTnd(),cant[1]},
          {concentrado.getIngredientes().get(2).getNombre(),concentrado.getIngredientes().get(2).getPc(),
           concentrado.getIngredientes().get(2).getTnd(),cant[2]},
          {concentrado.getIngredientes().get(3).getNombre(),concentrado.getIngredientes().get(3).getPc(),
           concentrado.getIngredientes().get(3).getTnd(),cant[3]},
          {concentrado.getIngredientes().get(4).getNombre(),concentrado.getIngredientes().get(4).getPc(),
           concentrado.getIngredientes().get(4).getTnd(),cant[4]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
    if(numeroIng == 6) {
      int cant[] = concentrado.getCantidad();
      Object[] titulo = {"*INGREDIENTES*","*PC*","*TND*","*CAN*"};
      Object[][] info = {{"ING","%PC","%TND","%CAN"},
          {concentrado.getIngredientes().get(0).getNombre(),concentrado.getIngredientes().get(0).getPc(),
           concentrado.getIngredientes().get(0).getTnd(),cant[0]},
          {concentrado.getIngredientes().get(1).getNombre(),concentrado.getIngredientes().get(1).getPc(),
           concentrado.getIngredientes().get(1).getTnd(),cant[1]},
          {concentrado.getIngredientes().get(2).getNombre(),concentrado.getIngredientes().get(2).getPc(),
           concentrado.getIngredientes().get(2).getTnd(),cant[2]},
          {concentrado.getIngredientes().get(3).getNombre(),concentrado.getIngredientes().get(3).getPc(),
           concentrado.getIngredientes().get(3).getTnd(),cant[3]},
          {concentrado.getIngredientes().get(4).getNombre(),concentrado.getIngredientes().get(4).getPc(),
           concentrado.getIngredientes().get(4).getTnd(),cant[4]},
          {concentrado.getIngredientes().get(5).getNombre(),concentrado.getIngredientes().get(5).getPc(),
           concentrado.getIngredientes().get(5).getTnd(),cant[5]}};
      table = new JTable(info,titulo);
      table.setForeground(new Color(1, 1, 1));
      table.setBackground(new Color(255, 182, 193));
      panelTabla.add(table);
      panelTabla.updateUI();
    }
  }
	public void exporta() {
		
		if(((String)comboBox.getSelectedItem()).equals("-")) {
			JOptionPane.showMessageDialog( null,"Selecciona un formato de exportacion");
		}else {
			JOptionPane.showMessageDialog( null,"Tabla de mezcla guardada en dispositivo");
			tarjetero.show(contentPane,"menu2");
		}
		
	}
}
