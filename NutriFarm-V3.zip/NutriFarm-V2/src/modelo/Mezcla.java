package modelo;

import java.util.LinkedList;

public class Mezcla {

  private LinkedList<Ingrediente> ingredientes;
  private Animal animal;
  private int Cantidad[] = {15,14,35,11,6,9};

  /**
   * Contructor que recive como parametros una lista de ingredientes y un animal.
   */
  public Mezcla(LinkedList<Ingrediente> ingredientes, Animal animal) {
    super();
    this.ingredientes = ingredientes;
    this.animal = animal;
  }
  
  /**
   * Contructor instancia objetos.
   */
  public Mezcla() {
    this.ingredientes = new LinkedList<Ingrediente>();
    this.animal = new Animal();
  }

  public void agregarIngrediente(Ingrediente ingre) {
    ingredientes.add(ingre);
  }

  public LinkedList<Ingrediente> getIngredientes() {
    return ingredientes;
  }

  public void setIngredientes(LinkedList<Ingrediente> ingredientes) {
    this.ingredientes = ingredientes;
  }

  public Animal getAnimal() {
    return animal;
  }

  public void setAnimal(Animal animal) {
    this.animal = animal;
  }

  public int[] getCantidad() {
    return Cantidad;
  }

  public void setCantidad(int cantidad[]) {
    Cantidad = cantidad;
  }

}
