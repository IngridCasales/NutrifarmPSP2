package modelo;

import java.util.LinkedList;

public class Animal {

  private String especie;
  private String etapa;
  private String rangoDePeso;
  private int ganancia;
  
  /**
   * Constructor inicializa atributos. 
   */
  public Animal() {
    this.especie = null;
    this.etapa = null;
    this.ganancia = 0;
    this.rangoDePeso = null;
  }
  
  /**
   * Constructor que recive parametros. 
   */
  public Animal(String especie, String etapa, String peso, int ganancia) {
    this.especie = especie;
    this.etapa = etapa;
    this.ganancia = ganancia;
    this.rangoDePeso = peso;
  }
  
  /**
   * Proporciona todos los animales disponibles.
   * Posterirormente se modificara este metodo para
   * que reciva como parametro la lista e animales
   * proprocionada por una consulta a la base de datos  
   */
  public LinkedList<Animal> obtenerAnimales() {
    LinkedList<Animal> animales = new LinkedList<Animal>();
    Animal a1 = new Animal("Vaca","Crecimiento","350-400",0);
    Animal a2 = new Animal("Vaca","Lactante","300-350",0);
    Animal a3 = new Animal("Borrego","Crecimiento","200-250",0);
    Animal a4 = new Animal("Borrego","Mantenimiento","300-350",0);
    Animal a5 = new Animal("Vaca","Engoda","400-450",0);
    animales.add(a1);
    animales.add(a2);
    animales.add(a3);
    animales.add(a4);
    animales.add(a5);
    return animales;  
  }
  
  public String getEspecie() {
    return especie;
  }
  
  public void setEspecie(String especie) {
    this.especie = especie;
  }

  public String getEtapa() {
    return etapa;
  }
  
  public void setEtapa(String etapa) {
    this.etapa = etapa;
  }
  
  public String getRangoDePeso() {
    return rangoDePeso;
  }
  
  public void setPeso(String peso) {
    this.rangoDePeso = peso;
  }
  
  public int getGanancia() {
    return ganancia;
  }
  
  public void setGanancia(int ganancia) {
    this.ganancia = ganancia;
  }

}
