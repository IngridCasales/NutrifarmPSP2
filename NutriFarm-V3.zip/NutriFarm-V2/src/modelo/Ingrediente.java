package modelo;

import java.util.LinkedList;

public class Ingrediente {

  private String nombre;
  private String clasificacion;
  private int pc;
  private int tnd;
  private int cantidad;

  /**
   * Constructor que sin parametros.  
   */
  public Ingrediente() {

  }

  /**
   * Constructor que recive parametros.  
   */
  public Ingrediente(String nombre, String clasificacion, int pc, int tnd, int cantidad) {
    super();
    this.clasificacion = clasificacion;
    this.nombre = nombre;
    this.pc = pc;
    this.tnd = tnd;
    this.cantidad = cantidad;
  }

  /**
   * Proporciona todos los ingredientes disponibles.
   * Posterirormente se modificara este metodo para
   * que reciva como parametro la lista de ingredientes
   * proprocionada por la base de datos  
   */
  public LinkedList<Ingrediente> obtenerIngredientes() {
    LinkedList<Ingrediente> ingredientes = new LinkedList<Ingrediente>();
    Ingrediente i1 = new Ingrediente("Maiz","Proteinico",34,35,5);
    Ingrediente i2 = new Ingrediente("Paja de garbanzo","Energetico",21,32,7);
    Ingrediente i3 = new Ingrediente("Grano de cebada","Energetico",56,78,3);
    Ingrediente i4 = new Ingrediente("Pasta de girasol","Forraje",46,67,10);
    Ingrediente i5 = new Ingrediente("Pulido de arroz","Forraje",32,33,21);
    Ingrediente i6 = new Ingrediente("Melasa de caña","Proteinico",43,65,11);
    Ingrediente i7 = new Ingrediente("Alfalfa","Forraje",33,44,22);
    Ingrediente i8 = new Ingrediente("Trigo","Energetico",10,90,18);
    ingredientes.add(i1);
    ingredientes.add(i2);
    ingredientes.add(i3);
    ingredientes.add(i4);
    ingredientes.add(i5);
    ingredientes.add(i6);
    ingredientes.add(i7);
    ingredientes.add(i8);
    return ingredientes;  
  }
  
  public String getNombre() {
    return nombre;
  }
  
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public int getPc() {
    return pc;
  }
  
  public void setPc(int pc) {
    this.pc = pc;
  }
  
  public int getTnd() {
    return tnd;
  }
  
  public void setTnd(int tnd) {
    this.tnd = tnd;
  }
  
  public int getCantidad() {
    return cantidad;
  }
  
  public void setCantidad(int cantidad) {
    this.cantidad = cantidad;
  }

  public String getClasificacion() {
    return clasificacion;
  }

  public void setClasificacion(String clasificacion) {
    this.clasificacion = clasificacion;
  }
  
}
