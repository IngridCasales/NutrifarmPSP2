package baseDatos;

import java.util.List;
import modelo.Animal;

public interface AnimalDAO {
	
	public List<Animal> obtenerAnimales();

}
