
package baseDatos;

import java.util.List;

import modelo.Clasificacion;

public interface ClasificacionDAO {
  
  public List<Clasificacion> obtnenerClasificaciones();
  
}
