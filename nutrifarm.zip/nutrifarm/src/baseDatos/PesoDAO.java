
package baseDatos;

import java.util.List;

import modelo.Peso;

public interface PesoDAO {
  
  public List<Peso> obtenerPesos();
  
}
