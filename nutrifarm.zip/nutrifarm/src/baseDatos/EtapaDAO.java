
package baseDatos;

import java.util.List;

import modelo.Etapa;

public interface EtapaDAO {
  
  public List<Etapa> obtenerEtapas();
  
}
