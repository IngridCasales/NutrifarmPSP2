
package modelo;

import java.util.Date;
import java.util.List;

public class Mezcla {
  
  private int num_mezcla;
  private Date fecha;
  private String nota;
  private String animal_especie;
  private int animal_kg;
  private String animal_descrip;
  private List<Cantidad> cantidades;
  
  public Mezcla(int num_mezcla,Date fecha,String nota,String animal_especie,
      int animal_kg,String animal_descrip,List<Cantidad> cantidades) {
    this.num_mezcla = num_mezcla;
    this.fecha = fecha;
    this.nota = nota;
    this.animal_especie = animal_especie;
    this.animal_kg = animal_kg;
    this.animal_descrip = animal_descrip;
    this.cantidades = cantidades;
  }
  
  public Mezcla() {
    
  }
  
  public int getNum_mezcla() {
    return num_mezcla;
  }

  public Date getFecha() {
    return fecha;
  }

  public String getNota() {
    return nota;
  }

  public String getAnimal_especie() {
    return animal_especie;
  }

  public int getAnimal_kg() {
    return animal_kg;
  }

  public String getAnimal_descrip() {
    return animal_descrip;
  }

  public List<Cantidad> getCantidades() {
    return cantidades;
  }

  public void setNum_mezcla(int num_mezcla) {
    this.num_mezcla = num_mezcla;
  }

  public void setFecha(Date fecha) {
    this.fecha = fecha;
  }

  public void setNota(String nota) {
    this.nota = nota;
  }

  public void setAnimal_especie(String animal_especie) {
    this.animal_especie = animal_especie;
  }

  public void setAnimal_kg(int animal_kg) {
    this.animal_kg = animal_kg;
  }

  public void setAnimal_descrip(String animal_descrip) {
    this.animal_descrip = animal_descrip;
  }

  public void setCantidades(List<Cantidad> cantidades) {
    this.cantidades = cantidades;
  }

}
