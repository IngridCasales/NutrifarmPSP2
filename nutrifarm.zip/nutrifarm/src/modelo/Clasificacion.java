
package modelo;

public class Clasificacion {
  
  private String tipo;
  
  public Clasificacion(String tipo) {
    this.tipo = tipo;
  }
  
  public Clasificacion() {
    
  }

  public String getTipo() {
    return tipo;
  }

  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
  
}
