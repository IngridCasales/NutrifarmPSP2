
package modelo;

public class Peso {
  
  private int kg;

  public Peso(int kg) {
    this.kg = kg;
  }
  
  public Peso() {
    
  }

  public int getKg() {
    return kg;
  }

  public void setKg(int kg) {
    this.kg = kg;
  }
  
}
